import networkx as nx

def ER(n):    # write Fibonacci series up to n
    G=nx.gnp_random_graph(n,0.1)
    return G
	# print G.adjacency_matrix